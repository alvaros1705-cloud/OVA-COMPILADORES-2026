// Error sintáctico
int x = ;
