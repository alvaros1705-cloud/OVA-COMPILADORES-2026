# MiniCompilador

Compilador completo para el lenguaje **MiniC** (.mc), implementado en Python.

## Fases implementadas

1. **Análisis Léxico** — Tokenización con manejo de errores
2. **Análisis Sintáctico** — Parser recursivo descendente
3. **Análisis Semántico** — Verificación de tipos y scopes
4. **Generación de Código Intermedio** — Cuádruplas (TAC)

## Lenguaje MiniC

```
// Variables
int x = 10;
float pi = 3.14;
string msg = "hola";
bool flag = true;

// Funciones
func suma(int a, int b) : int {
    return a + b;
}

// Control
if (x > 5) { print(x); } else { print(0); }
while (x > 0) { x = x - 1; }

// Salida
print("resultado");
```

## Ejecución

```bash
# Backend
cd backend && uvicorn main:app --reload

# Frontend
cd frontend && flask run
```

## Estructura
- `backend/app/compiler/` — Motor del compilador
- `frontend/` — Interfaz web
- `examples/` — Programas de ejemplo .mc
